class DbException(Exception):
    pass


__all__ = ["DbException"]
