from .used_assets_endpoints import init_submodule as asset_init_submodule

__all__ = ["asset_init_submodule"]
