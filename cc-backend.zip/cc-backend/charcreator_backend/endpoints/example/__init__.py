from .example_endpoints import init_submodule

__all__ = ["init_submodule"]