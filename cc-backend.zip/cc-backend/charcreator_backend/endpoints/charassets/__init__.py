from .charassets_endpoints import init_submodule as charassets_init_submodule


__all__ = ["charassets_init_submodule"]